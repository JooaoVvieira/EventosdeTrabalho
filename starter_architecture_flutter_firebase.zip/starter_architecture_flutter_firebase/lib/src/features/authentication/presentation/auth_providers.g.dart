// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'auth_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$authProvidersHash() => r'ae6cefe8190c6d4e0c24eed661e7889031bfabda';

/// See also [authProviders].
@ProviderFor(authProviders)
final authProvidersProvider =
    Provider<List<AuthProvider<AuthListener, AuthCredential>>>.internal(
  authProviders,
  name: r'authProvidersProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$authProvidersHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef AuthProvidersRef
    = ProviderRef<List<AuthProvider<AuthListener, AuthCredential>>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
