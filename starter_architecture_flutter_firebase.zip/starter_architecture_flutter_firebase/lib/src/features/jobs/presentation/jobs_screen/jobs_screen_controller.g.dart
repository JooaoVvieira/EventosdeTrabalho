// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'jobs_screen_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$jobsScreenControllerHash() =>
    r'e3a40258404cf512fd12924d8f0a485f75d7d6fb';

/// See also [JobsScreenController].
@ProviderFor(JobsScreenController)
final jobsScreenControllerProvider =
    AutoDisposeAsyncNotifierProvider<JobsScreenController, void>.internal(
  JobsScreenController.new,
  name: r'jobsScreenControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$jobsScreenControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$JobsScreenController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
