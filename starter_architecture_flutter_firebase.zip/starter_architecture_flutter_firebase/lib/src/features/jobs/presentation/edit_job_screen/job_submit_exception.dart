class JobSubmitException {
  String get title => 'Nome já usado';
  String get description => 'Escolha um nome de trabalho diferente';

  @override
  String toString() {
    return '$title. $description.';
  }
}
