// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'edit_job_screen_controller.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$editJobScreenControllerHash() =>
    r'e2985913f443860f6aa9d1b0aa462d4e5c25bed4';

/// See also [EditJobScreenController].
@ProviderFor(EditJobScreenController)
final editJobScreenControllerProvider =
    AutoDisposeAsyncNotifierProvider<EditJobScreenController, void>.internal(
  EditJobScreenController.new,
  name: r'editJobScreenControllerProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$editJobScreenControllerHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$EditJobScreenController = AutoDisposeAsyncNotifier<void>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
