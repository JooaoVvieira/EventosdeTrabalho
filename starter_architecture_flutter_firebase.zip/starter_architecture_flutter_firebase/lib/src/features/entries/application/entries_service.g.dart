// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'entries_service.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$entriesServiceHash() => r'ad6f017678723501d64b7d33ea05ce3553cc010b';

/// See also [entriesService].
@ProviderFor(entriesService)
final entriesServiceProvider = AutoDisposeProvider<EntriesService>.internal(
  entriesService,
  name: r'entriesServiceProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$entriesServiceHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef EntriesServiceRef = AutoDisposeProviderRef<EntriesService>;
String _$entriesTileModelStreamHash() =>
    r'69af265d2969a10a62e0b9e7b679ce336445b91c';

/// See also [entriesTileModelStream].
@ProviderFor(entriesTileModelStream)
final entriesTileModelStreamProvider =
    AutoDisposeStreamProvider<List<EntriesListTileModel>>.internal(
  entriesTileModelStream,
  name: r'entriesTileModelStreamProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$entriesTileModelStreamHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef EntriesTileModelStreamRef
    = AutoDisposeStreamProviderRef<List<EntriesListTileModel>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member
