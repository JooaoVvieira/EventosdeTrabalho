class Strings {
  // Generic strings
  static const String ok = 'OK';
  static const String cancel = 'Cancelar';

  // Logout
  static const String logout = 'Sair';
  static const String logoutAreYouSure =
      'Tem certeza que deseja sair?';
  static const String logoutFailed = 'Falha ao sair';

  // Sign In Page
  static const String signIn = 'Entrar';
  static const String signInWithEmailPassword = 'Entrar com e-mail e senha';
  static const String goAnonymous = 'Entrar como anônimo';
  static const String or = 'ou';
  static const String signInFailed = 'Falha ao entrar';

  // Home page
  static const String homePage = 'Página inicial';

  // Jobs page
  static const String jobs = 'Trabalhos';

  // Entries page
  static const String entries = 'Entradas';

  // Account page
  static const String account = 'Conta';
  static const String accountPage = 'Página da conta';
}
