class Keys {
  static const String emailPassword = 'email-senha';
  static const String anonymous = 'anônimo';
  static const String tabBar = 'tabBar';
  static const String jobsTab = 'jobsTab';
  static const String entriesTab = 'entriesTab';
  static const String accountTab = 'accountTab';
  static const String logout = 'sair';
  static const String alertDefault = 'alertDefault';
  static const String alertCancel = 'alertCancel';
}
